<script setup>
import ChatView from './views/ChatView.vue'
import ToastContainer from './components/ToastContainer.vue'
import ConfirmDialogHost from './components/ConfirmDialogHost.vue'
</script>

<template>
  <ChatView />
  <ToastContainer />
  <ConfirmDialogHost />
</template>
