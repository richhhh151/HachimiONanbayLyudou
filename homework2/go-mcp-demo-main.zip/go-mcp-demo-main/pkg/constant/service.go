package constant

const (
	ServiceNameAPI       = "host"
	ServiceNameMCPLocal  = "mcp_local"  // 仅本地工具的MCP服务
	ServiceNameMCPRemote = "mcp_remote" // 涉及到外部请求的MCP服务
)
