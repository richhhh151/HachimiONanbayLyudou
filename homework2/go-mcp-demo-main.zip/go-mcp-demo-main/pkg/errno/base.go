package errno

var (
	OllamaInternalStopStream = NewErrNo(OllamaInternalStopStreamCode, "服务内部通知ollama停止流")
)
